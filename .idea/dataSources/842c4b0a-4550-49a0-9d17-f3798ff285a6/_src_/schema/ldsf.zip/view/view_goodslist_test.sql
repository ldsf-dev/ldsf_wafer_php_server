CREATE VIEW view_goodslist_test AS
  SELECT
    `ldsf`.`t_good`.`good_id`                                               AS `good_id`,
    `ldsf`.`t_good`.`good_name`                                             AS `good_name`,
    count(`ldsf`.`t_good_comment`.`good_comment_good_id`)                   AS `cnt_comments`,
    format(ifnull(avg(`ldsf`.`t_good_comment`.`good_comment_score`), 0), 1) AS `avg_commentscore`,
    format((`ldsf`.`t_good`.`good_price` / 100), 2)                         AS `good_price`,
    `ldsf`.`t_good`.`good_thumbnail`                                        AS `good_thumbnail`,
    `ldsf`.`t_good`.`good_desc`                                             AS `good_desc`,
    `ldsf`.`t_good`.`good_class_1`                                          AS `good_class_1`,
    `ldsf`.`t_good`.`good_class_2`                                          AS `good_class_2`,
    `ldsf`.`t_good`.`good_class_3`                                          AS `good_class_3`,
    `ldsf`.`t_good`.`good_class_4`                                          AS `good_class_4`,
    `ldsf`.`t_good`.`good_class_5`                                          AS `good_class_5`
  FROM (`ldsf`.`t_good`
    LEFT JOIN `ldsf`.`t_good_comment` ON ((`ldsf`.`t_good`.`good_id` = `ldsf`.`t_good_comment`.`good_comment_good_id`)))
  WHERE ((`ldsf`.`t_good`.`good_status` = 99) AND (`ldsf`.`t_good`.`good_type` = 1))
  GROUP BY `ldsf`.`t_good`.`good_id`;
